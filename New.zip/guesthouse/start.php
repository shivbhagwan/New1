<!DOCTYPE html>
<html>
<body>

<p><a href="form_login2.php">Guest Users</a></p>
<p><a href="form_login1.php">Registered Users</a></p>

</body>
</html>