<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<!-- Mirrored from gymkhana.iitb.ac.in/~hostels/guest.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 19 Feb 2016 14:08:29 GMT -->
<head>

	<link rel="icon" type="image/vnd.microsoft.icon" href="icon.html">
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="description" content="_your description goes here_" />
<meta name="keywords" content="_your,keywords,goes,here_" />
<link rel="stylesheet" type="text/css" href="style.css" media="screen" title="style (screen)" />
<script type="text/javascript" src="script.js">
	</script>
<title>Hostel Affairs(HA)</title>

</head>
<body>
<div id="left" style="overflow:auto"></div>



<div id="main">
<div align="center" style="font-size:24px; "><font size="+3">G</font>uest <font size="+3">A</font>ccomodation <font size="+3">B</font>ooking<font size="+3"> S</font>ystem<br><font size="-2">Portal for the Admin
</font></div>


<font size="-1">
<br><br>

<form method="POST" action="verify_admin.php" enctype="multipart/form-data" >
<table cellspacing="5px">
<tr>
	<tr><th><h2>Your details:</h2></th></tr>
<td  width="40%">
<font size="-1">UserID : </font>
</td>
<td>
 <input  type="text" name="uid"  style="background-color:#222; padding:5px;  height:17px; width:200px; color:orange; border:0; opacity:0.8;"/>
	<!--font size="-1">&nbsp; @ iitj.ac.in</font><br-->
</td>
</tr>
<tr>
<td>
<font size="-1">Password :</font>
</td>
<td>
 <input  type="password" name="pwd"  style="background-color:#222; padding:5px;  height:17px; width:200px; color:orange; border:0; opacity:0.8"/>
	<br>
</td>
</tr>
</table>
<input type="submit" value="Submit">

	<br />
	<br />
	<br />
	

</font>
</div>

<!--onclick="addInput()"-->
</body>
</html>
