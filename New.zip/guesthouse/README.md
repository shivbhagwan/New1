# guest_house_management_system

Team members
Shiv Bhagwan
Vivek


*************************************************************************************************************************************
1)Software requirements : xampp
2)Install xampp and start apache and mysql servers.
3)Go to the htdocs folder in xampp and make a new directory (your_directory) where the website files will be stored.
4)Clone the files into that folder.

***************************************************************************************************************************************

1)The database with the name db_software is to be made containing tables with names admin_table , guest_user , registered_user and room_details , the sql scripts are given in the file database_scripts.
2)Now open any browser and to start the main or first page for users write localhost/your_directory/index.html and you can navigate from this page accordingly.
3)To open the first page for admin write localhost/your_directory/admin.html and navigate accordingly.
4)For seeing the changes in the database type localhost/phpmyadmin in a new tab which opens all the databases.

****************************************************************************************************************************************
