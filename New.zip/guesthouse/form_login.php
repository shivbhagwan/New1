

<html>
<body>
<form action="login.php" method="post">
User _id.: <input type="text" name="User_id"><br>
Password: <input type="text" name="Password"><br>
<input type="submit" name="submit">
</form>





</body>
</html>