<?php
require "connect.inc.php";

session_start();
$user_check=$_SESSION['login_user'];
if($_SERVER["REQUEST_METHOD"] == "POST")
{


$type=$_POST['type']; 
$author=$_POST['author'];
$department=$_POST['department'];
$related=$_POST['publication']; 
$title=$_POST['title'];
$user_check=$_SESSION['login_user'];

	
// Check if a file has been uploaded
if(isset($_FILES['papers'])) {
    // Make sure the file was sent without errors
    if($_FILES['papers']['error'] == 0) {
        // Connect to the database
        
 
        // Gather all required data
        $filename = mysql_real_escape_string($_FILES['papers']['name']);
       
        $data = mysql_real_escape_string(file_get_contents($_FILES  ['papers']['tmp_name']));
 
 
$sql="INSERT INTO `publication`(`id`,`LDAP`, `type`,`author`, `detail`, `title`,`data`, `filename`,`created`,department) VALUES ('','$user_check','$type','$author','$related`','$title','$data','$filename',NOW(),'$department')";

$result6=mysql_query($sql);
 if(! $result6 ) {
               die( mysql_error());
            }


    }
 
   
}
else
{
    echo mysql_error();
}
 
// Echo a link back to the main page
echo '<script>alert("Succesfully Added");</script>';
header("refresh:0;url=admin.php");
 
 	

}
