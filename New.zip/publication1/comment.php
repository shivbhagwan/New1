
<?php
require "connect.inc.php";
session_start();
$user_check=$_SESSION['login_user'];
$login=$_SESSION["login"];
if($login==0)
{
	echo "<script>alert('Please Login First For Comment');</script>";
	header( "refresh:0;url=index.php" );
}
if(isset($_POST["title"])&&isset($_POST["author"])&&isset($_POST["type"]))
{
	$title=$_POST["title"];
	$author=$_POST["author"];
	$type=$_POST["type"];	
}

?>

 <!DOCTYPE html>
<html >
  <head>
    <meta charset="UTF-8">
    <title>Comment </title>	
        <link rel="stylesheet" href="css/style2.css">
    
  </head>
<?php
if(isset($_POST["comment"])){
	$comment=$_POST["comment"];
	$title=$_POST["title"];
	$author=$_POST["author"];
	$type=$_POST["type"];
	$query="INSERT INTO `comment`(`id`, LDAP,`title`, `author`, `type`, `comment`) VALUES ('','$user_check','$title','$author','$type','$comment')";
	if($result=mysql_query($query))
	{
		echo "<script>alert('Successfully Commented');</script>";
		header( "refresh:0;url=index.php" );
	}
	else
	{
		echo mysql_error();
		header( "refresh:0;url=index.php" );
	}
}


?>


  <body background="images/B.jpg">

    <div id="form-main">
  <div id="form-div">
    <form class="form" method="post" id="form1" action="comment.php">
      
      <p class="text">
        <textarea name="comment" class="validate[required,length[6,300]] feedback-input" id="comment" placeholder="Comment"></textarea>
      </p>
      <input type="hidden" value="<?php echo $title;?>" name="title"/>
      <input type="hidden" value="<?php echo $author;?>" name="author"/>
      <input type="hidden" value="<?php echo $type;?>" name="type"/>
      
      <div class="submit">
        <input type="submit" value="Submit" id="button-blue"/>
        <div class="ease"></div>
      </div>
    </form>
  </div>
  
  </body>
</html>

 