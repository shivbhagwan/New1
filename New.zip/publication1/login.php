<?php
require "connect.inc.php";
session_start();
if(@$_SESSION['login']){
header("Location: admin.php");	
}

if($_SERVER["REQUEST_METHOD"] == "POST")
{
// username and password sent from form 

$myusername=addslashes($_POST['ldap']); 
$mypassword=addslashes($_POST['password']); 


$sql="SELECT ID FROM register WHERE LDAP='$myusername' and Password='$mypassword'";
$result=mysql_query($sql);
$count=mysql_num_rows($result);
if($count==1)
{
 //session_register("myusername");
 $_SESSION['login']=1;
$_SESSION['login_user']=$myusername;
header("location: admin.php");
}
else 
{
echo"<script>alert('Username and password are not matching');</script>";

}

}  
?>
<!DOCTYPE html>
<html>
<head>
	<title>Login Page</title>
	<link rel="stylesheet" href="normalize.css">
	<link rel="stylesheet" href="style.css">
</head>
<body>
	 <img style='vertical-align:middle;width:80px ;margin:20px;' src='images/D.gif'>
<div style='vertical-align:middle; display:inline;font-size:30px;color:white;'>
<strong>IIT JODHPUR</strong>
</div>
	<section class="loginform cf" style=" margin-top:200px;">
		<form name="login" action="login.php" method="POST" accept-charset="utf-8">
			<ul>
				<li>
					<label for="usermail">LDAP</label>
					<input type="text" name="ldap" placeholder="Your LDAP" required>
				</li>
				<li>
					<label for="password">Password</label>
					<input type="password" name="password" placeholder="********" required></li>
				
				<li>
					<input type="submit" value="Login">
				</li>
				<li><br>
				   <a href="forgotpassword.php">Forgot Password</a>
				</li>
			</ul>
		</form>
	</section>
</body>
</html>
