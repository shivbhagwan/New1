<?php
// Check if a file has been uploaded

//include("config.php");	

require "connect.inc.php";
session_start();

if($_SERVER["REQUEST_METHOD"] == "POST")
{


$Name=$_POST['name']; 
$Department=$_POST['department'];

$Detail=$_POST['detail']; 
$Mobile=$_POST['mobile'];

$Email=$_POST['email']; 
$Address=$_POST['address']; 
$Research=$_POST['research']; 

$user_check=$_SESSION['login_user'];

// Make sure the file was sent without errors
    if($_FILES['cv']['error'] == 0) {
       
 
        // Gather all required data
        $filename =mysql_real_escape_string($_FILES['cv']['name']);
        $data = mysql_real_escape_string(file_get_contents($_FILES  ['cv']['tmp_name']));
 
        // Create the SQL query
	
$sql="INSERT INTO `profile`(`Address`, `Department`,`LDAP`, `Detail`, `Email`, `Mobile`, `Name`, `Research`,`Data`, `filename`) VALUES ('$Address','$Department','$user_check','$Detail','$Email','$Mobile','$Name','$Research','$data','$filename')";

$result = mysql_query($sql);

 if(! $result ) {
               echo mysql_error();
            }
}
 
    // Close the mysql connection
    
}

// Echo a link back to the main page
echo "<script>alert('profile add successfully');</script>";
header( "refresh:0;url=admin.php" );

?>
 