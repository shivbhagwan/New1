<?php
  $hostname='localhost';
  $username='root';
  $password='';
  @mysql_connect($hostname,$username,$password)or die('could not connect');
        mysql_select_db('publication3')or die('could not connect');
  ?>