

<!DOCTYPE html>
<html >
  <head>
    <meta charset="UTF-8">
    <title>Comment </title>
    
    
    
    
        <link rel="stylesheet" href="css/style2.css">

    
    
    
  </head>

  <body background="images/B.jpg">

    
  <div id="form-div" style="margin-top:100px;">
    <form class="form" method="get" action="getfile.php" id="form1">
      
      <p class="name">
        <input name="id" type="number" class="validate[required,custom[onlyLetter],length[0,100]] feedback-input" placeholder="ID" id="name" />
      </p>
      
      
      
      <div class="submit">
        <input type="submit" value="Download" id="button-blue"/>
        <div class="ease"></div>
      </div>
    </form>
  </div>
  
   

 </body>
</html>