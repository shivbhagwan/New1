<?php
// Make sure an ID was passed
require "connect.inc.php";
if(isset($_GET['id'])) {
// Get the ID
    $id = intval($_GET['id']);
 
    // Make sure the ID is in fact a valid ID
    if($id <= 0) {
        die('The ID is invalid!');
    }
    else {
        
       
 
        // Fetch the file information
        $query = "
            SELECT `filename`, `created`, `data`
            FROM `publication`
            WHERE `id` = {$id}";
        $result = mysql_query($query);
 
        if($result) {
            // Make sure the result is valid
            if(mysql_num_rows($result) == 1) {
            // Get the row
                $row = mysql_fetch_assoc($result);
 
                // Print headers
                
                header("Content-Time: ". $row['created']);
                header("Content-Disposition: attachment; filename=". $row['filename']);
 
                // Print data
                echo $row['data'];
			
            }
            else {
                echo 'Error! No file exists with that ID.';
            }
 
            
			
			
        }
        else {
            echo mysql_error();
        }
       
    }
}
else {
    echo 'Error! No ID was passed.';
}
?>
