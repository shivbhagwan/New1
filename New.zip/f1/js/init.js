(function($){
  $(function(){

    $('.button-collapse').sideNav();
    $('.parallax').parallax();

  }); // end of document ready
})(jQuery); // end of jQuery name space



  $(document).ready(function(){
      $('.carousel').carousel();
      $('.slider').slider({full_width: true});
		setBindings();

    });




$(window).scroll(function(){
	var wScroll=$(this).scrollTop();

	$('#parallax-heading').css({
		'transform':'translate(0px,'+wScroll*0.3+'%)'
	});
});










var nav=$(".navbar");

$(window).scroll(function(){
	if($(this).scrollTop() >140){
		nav.addClass("navbar-fixed");
		nav.addClass("pos-absolute");
		$("#logoimg").css("visibility","visible");
	}
	else{
		nav.removeClass("navbar-fixed");	
		nav.removeClass("pos-absolute");
		$("#logoimg").css("visibility","hidden");

	}
});



$(".card").mouseover(function(){
	$(".card").css("opacity","0.6");
	$(this).css("opacity","1");

});
$(".card").mouseout(function(){
	$(".card").css("opacity","1");
});