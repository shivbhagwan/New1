<?php
  $hostname='localhost';
  $username='root';
  $password='';
  @mysql_connect($hostname,$username,$password)or die('could not connect');
        mysql_select_db('flipppu2_stores')or die('could not connect');
  ?>