<?php 
require "connect.inc.php";
$store_name="snapdeal";
$query="select cashback,logosquare from stores where storeid='$store_name'";
$result=mysql_query($query);
$sql_name = mysql_fetch_array($result);
$cashback=$sql_name["cashback"];
$logosquare=$sql_name["logosquare"];

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Homepage</title>

  <html lang="en">
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

  <!-- CSS  -->
  <link href="css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <link href="css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <!-- Materialized Icons -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  

<style>
/* columns of same height styles */

.row-full-height {
  height: 100%;
}

.row-same-height {
  display: table;
  width: 100%;
  /* fix overflow */
  table-layout: fixed;
}
.col-xs-height {
  display: table-cell;
  float: none !important;
}

@media (min-width: 768px) {
  .col-sm-height {
    display: table-cell;
    float: none !important;
  }
}
@media (min-width: 992px) {
  .col-md-height {
    display: table-cell;
    float: none !important;
  }
}
@media (min-width: 1200px) {
  .col-lg-height {
    display: table-cell;
    float: none !important;
  }
}




.profilepic >img{
border-radius:75px;
margin-left:5%;
margin-top:125px;
border:1px solid #000000;
}
.profilepic >img:hover{

border-radius:75px;
-webkit-box-shadow: inset 0px 0px 65px -10px rgba(0,0,0,1);
-moz-box-shadow: inset 0px 0px 65px -10px rgba(0,0,0,1);
box-shadow: inset 0px 0px 65px -10px rgba(0,0,0,1);
border:12px solid #e1e1d0;
}

</style>
</head>
<body onload="startTime()">
 


<!-- Navigation Bar -->
<div  >
<nav class="white " style="height:150px;">
    <div class="container ">
     
<a id="logo-container" href="#" class="brand-logo"><img  src="images/FPLogo.png" style="width:200px;height:130px;margin:0px;" alt="Flip Paisa Logo"></a>


 </div>
  </nav>
</div>

<div class="navbar" >
<nav class="white " role="navigation">
    <div class="nav-wrapper navbar container ">

      <a id="logo-container" href="#" class="brand-logo"><img src="images/FPLogo.png" id="logoimg" style="width:150px;height:80px;margin:0px;visibility:hidden;" alt="Flip Paisa Logo"></a>
      
      <ul class="right hide-on-med-and-down navigation" >
        <li><a id="home" href="#">Home</a></li>
        <li><a id="AllStores" href="#">All Stores</a></li>
        <li><a id="FAQ" href="#">FAQ's</a></li>
       <li><a id="HowItWorks" href="#">How It Works</a></li>
       <li><a id="Refer&Earn" href="#">Refer & Earn</a></li>
       <li><a id="Suport" href="#">Support</a></li>
      </ul>

      
    </div>
  </nav>
</div><div id="txt"></div><br>

<div style="margin:0 7%;">

<div class="row"><div class="row-same-height row-full-height">
<div class="col-md-9 col-md-height col-full-height">
<div class="item"><div class="content">
<div >


<div style="background-size: cover;height:200px;width:100%;background-image:url('z.png')">

<a class="profilepic" >
<?php
echo '<img height="150" width="150" alt="'.$store_name.'" src="data:logosquare;base64,'.$logosquare.' ">';
?>

</a>

</div></div>
<div style="margin-bottom:40px;background-color:#00331a;width:100%;text-align:center;padding:5px;font-size:20px;color:white">
<?php
echo $store_name;
?>
</div >
</div></div></div>
<div class="col-md-3 col-md-height col-full-height panel panel-default">
<div class="item"><div class="content">
<div style="font-size:20px;color:black;"> 
Upto <?php echo " ".$cashback." ";?><span style="color:blue">F</span><span style="color:green">P</span> Rewards on <?php echo $store_name;?><br>
<br>
</div>

<button type="button" style="margin-left:25%"class="btn btn-primary" >Go to <?php echo $store_name;?></button>

</div></div></div>
</div></div>

<div class="row "><div class="row-same-height row-full-height">
<div class="col-md-4 col-md-height col-full-height"style="background-color:#F6F6F6;box-shadow:21px 6px 50px -30px  rgba(0,0,0,0.75);">
 <div class="item"><div class="content">
<?php 
$query="SELECT longdesc,logobig,importantpoints from stores where storeid='$store_name'";
if($result=mysql_query($query))
{
	$sql_name = mysql_fetch_array($result);
$longdesc=$sql_name["longdesc"];
$logosmall=$sql_name["logobig"];
$importantpoints=$sql_name["importantpoints"];

echo '<img height="120" width="100%" alt="'.$store_name.'" src="data:logosquare;base64,'.$logosmall.' ">';
?>


<?php
echo '<p >'.$longdesc;
}
else{
	echo "error";
}


?>go to <?php echo $store_name;?> Via Flippaisa & Get upto <?php echo $cashback;?> cashback</p>
<br><br>
<table class="table ">
<thead>
<tr >
<th >Important Points</th>
</tr>
</thead>
<tbody>
<tr><td>
<?php

echo $importantpoints;
?>

</td>
</tr>
</tbody>
</table>
<table class="table">
<thead>
<tr>
<th>
</th>

</tr>

</thead>
<tbody>
 <tr >
		<td  style="font-size:14px;color:red; text-align:center;">Minimum Transaction Amount: Rs.<?php
		$query="select mta,aott from stores where storeid='$store_name'";
		$result=mysql_query($query);
		$sql_name = mysql_fetch_array($result);
		$mta=$sql_name["mta"];
		$aott=$sql_name["aott"];
		echo $mta;
		
		
		?>
		
		<br><br>Average order tracking time:<?php echo $aott;?></td>
		</tr>
</tbody>
</table>
</div></div></div>

<div class="col-md-4 col-md-height col-full-height"style=""><div class="item"><div class="content">
<h5 style="text-align:center;">CashBack Rates for April 2016</h5>
<?php
if($store_name=='flipkart')
{
	
?>
<table class="table table-striped table-bordered">
    <thead>
      <tr class="success">
	  
	  <th style="width:28%;">Mobile App</th>
        <th style="width:28%;">Website</th>
       <th>Details</th>
      </tr>
	  <tr class="info">
	  
	  <th style="width:28%;">Old--new</th>
        <th style="width:28%;">Old--new</th>
       <th style="font-size:11px;">Old->Old Flipkart Users<br>New->New Flipkart Users</th>
      </tr>
    </thead>
	<tbody>
	  <?php   
	    $query="select details,wn,wo,mn,mo from cashbackrates where storeid='$store_name'";
		$result=mysql_query($query);
		if(mysql_num_rows($result)>0)
		{
			while($sql_name = mysql_fetch_array($result))
			{
				$details=$sql_name["details"];
				$wn=$sql_name["wn"];
				$wo=$sql_name["wo"];
				$mn=$sql_name["mn"];
				$mo=$sql_name["mo"];
				?>
				<tr>
				<td><?php echo $mo.'%--'.$mn.'%';?></td>
				<td><?php echo $wo.'%--'.$wn.'%';?></td>
                <td style="font-size:12px;"><?php echo $details;?></td>				
				</tr><?php
			}
			}
		
		
		?>
       
    
      
    </tbody>
  </table>	
	
	<?php
}
else if($store_name=='snapdeal'){
	?>
<table class="table table-striped table-bordered">
    <thead>
      <tr class="success">
	  
	  <th style="width:28%;">New Snapdeal Users</th>
        <th style="width:28%;">Old Snapdeal Users</th>
       <th>Details</th>
      </tr>
	  <tr class="info">
	  
	  <th style="width:28%;font-size:11px;">OA <= 300 -- <br>OA > 300</th>
        <th style="width:28%;font-size:11px;">OA <= 1500 --<br> OA > 1500</th>
       <th >OA--> Order Amount</th>
      </tr>
    </thead>
	<tbody>
	  <?php   
	    $query="select details,wn,wo,mn,mo from cashbackrates where storeid='$store_name'";
		$result=mysql_query($query);
		if(mysql_num_rows($result)>0)
		{
			while($sql_name = mysql_fetch_array($result))
			{
				$details=$sql_name["details"];
				$wn=$sql_name["wn"];
				$wo=$sql_name["wo"];
				$mn=$sql_name["mn"];
				$mo=$sql_name["mo"];
				?>
				<tr>
				<td><?php echo $mo.'%--'.$mn.'%';?></td>
				<td><?php echo $wo.'%--'.$wn.'%';?></td>
                <td style="font-size:12px;"><?php echo $details;?></td>				
				</tr><?php
			}

		}
		
		
		?>
       
    
      
    </tbody>
  </table>	
	
	<?php
	
}
else{
?>
<table class="table table-striped table-bordered">
    <thead>
      <tr class="success">
	  
	  <th>CashBack</th>
        <th>Details</th>
       
      </tr>
    </thead>
	<tbody>
	  <?php   
	    $query="select details,c from cashbackrates where storeid='$store_name'";
		$result=mysql_query($query);
		if(mysql_num_rows($result)>0)
		{
			while($sql_name = mysql_fetch_array($result))
			{
				$details=$sql_name["details"];
				$c=$sql_name["c"];
				?>
				<tr>
				<td><?php echo $c;?></td>
                <td><?php echo $details;?></td>				
				</tr><?php
			}
			
			
		}
		
		
		?>
       
    
      
    </tbody>
  </table>
  <?php
}
  
  ?>
</div></div></div>
<div class="col-md-4 col-md-height col-full-height"style="box-shadow:-14px -2px 51px -25px  rgba(0,0,0,0.75);background-color:#F6F6F6">
<div class="item"><div class="content">
<?php

$m = 1;
$n = 1;
$count1 = 0;
$details1 = "";
$coupon = "";
$expiry = "";
$link = "";

$result = mysql_query("SELECT * FROM deals WHERE storeid = '$store_name'") or die (mysql_error());
	 $count1 = mysql_num_rows($result);
	
	//Condition of offer availability
if($count1 == 0){
echo '<img src="nooffer.png" >';	
} else{
echo '<img src="offor.png" >';	
} 
	?><div class="list-group"><?php 
while ($m <= $count1){
$sql_query = mysql_query("SELECT * FROM deals WHERE id='$n' AND storeid = '$store_name' LIMIT 1") or die (mysql_error());
		
		 if ((mysql_num_rows($sql_query)) == 0){
			 $n++;
		 }else{
		
			while($sql_name = mysql_fetch_array($sql_query)){
			$coupon = $sql_name['coupon'];
			$expiry = $sql_name['expiry'];
			$details1 = $sql_name['details'];
			$link = $sql_name['link'];
			$oid = $sql_name['id'];
			}
// Timer

echo "<script>

    CountDownTimer('"; print ($expiry); echo "', 'countdown"; print($n); echo "');";


echo "    function CountDownTimer(dt, id)
    {
        var end = new Date(dt);

        var _second = 1000;
        var _minute = _second * 60;
        var _hour = _minute * 60;
        var _day = _hour * 24;
        var timer;

        function showRemaining() {
            var now = new Date();
            var distance = end - now;
            if (distance < 0) {

                clearInterval(timer);
                document.getElementById(id).innerHTML = 'EXPIRED!';

                return;
            }
            var days = Math.floor(distance / _day);
            var hours = Math.floor((distance % _day) / _hour);
            var minutes = Math.floor((distance % _hour) / _minute);
            var seconds = Math.floor((distance % _minute) / _second);

			document.getElementById(id).innerHTML = 'Expires in: ';
            document.getElementById(id).innerHTML += days + ' Days ';
            document.getElementById(id).innerHTML += hours + ' Hrs ';
            document.getElementById(id).innerHTML += minutes + ' Mins ';
            document.getElementById(id).innerHTML += seconds + ' Secs';
			
        }

        timer = setInterval(showRemaining, 1000);
    }

</script> ";

//Timer





?>
  <a href="#" class="list-group-item list-group-item-info">
    <h5 class="list-group-item-heading"><?php echo $details1;    ?></h5>
    
	<p class="list-group-item-text"><?php
                                       echo '
                                         <div id="countdown">	<div id="countdown'; 
                                                                 print($n); 
                                                    echo '" style="color:#FF0004"> Getting Expiry Time...</div>
													<button type="button" style="margin-left:25%"class="btn btn-primary">Get this Deal </button>';
                                      echo '<div class="clear"></div>';

                                      

                                     echo '</div>';


$m++;
$n++;	
}
}
  ?></p>
  </a>
  

<?php

?></div>
</div></div></div>

</div>

</div>




</div>





<!-- Footer Section -->
<footer class="page-footer  light-blue darken-4">
          <div class="container ">
            <div class="row">
              <div class="col l3 s12">
                <h5 class="white-text">About FlipPaisa</h5>
                <ul>
                  <li><a class="grey-text text-lighten-3" href="http://www.flippaisa.com/about">About Us</a></li>
                  <li><a class="grey-text text-lighten-3" href="http://www.flippaisa.com/faq">FAQ's</a></li>
                  <li><a class="grey-text text-lighten-3" href="http://www.flippaisa.com/contact">Contact Us</a></li>
                  <li><a class="grey-text text-lighten-3" href="http://www.flippaisa.com/tnc">Terms and Conditions</a></li>
                  <li><a class="grey-text text-lighten-3" href="http://www.flippaisa.com/privacy">Privacy and Cookie Policy</a></li>
                </ul>
              </div>
              
              <div class="col l3 s12">
                <h5 class="white-text">Quick Links</h5>
                <ul>
                  <li><a class="grey-text text-lighten-3" href="http://www.flippaisa.com/how">How FlipPaisa Works</a></li>
                  <li><a class="grey-text text-lighten-3" href="http://www.flippaisa.com/r">Refer and Earn</a></li>
                  <li><a class="grey-text text-lighten-3" href="http://www.flippaisa.com/ticket">Missing CashBack</a></li>
                  <li><a class="grey-text text-lighten-3" href="http://www.flippaisa.com/student">Student Ambassdor Program</a></li>
                  <li><a class="grey-text text-lighten-3" href="http://www.flippaisa.com/internship">Internships</a></li>
                </ul>
              </div>

              <div class="col l3 s12">
                <h5 class="white-text">Other Products</h5>
                <ul>
                  <li><a class="grey-text text-lighten-3" href="http://blog.flippaisa.com/">FlipPaisa Blog</a></li>
                  <li><a class="grey-text text-lighten-3" href="http://www.flippaisa.com/chrome">FlipPaisa Chrome Extension</a></li>
                  <li><a class="grey-text text-lighten-3" href="http://www.flippaisa.com/partners">Become Our Partner</a></li>
                </ul>
              </div>
           

              <div class="col l3 s12">
                <h5 class="white-text">Popular Stores</h5>
                <ul>
                  <li><a class="grey-text text-lighten-3" href="http://www.flippaisa.com/store/?sid=flipkart">Flipkart</a></li>
                  <li><a class="grey-text text-lighten-3" href="http://www.flippaisa.com/store/?sid=paytm">Paytm</a></li>
                  <li><a class="grey-text text-lighten-3" href="http://www.flippaisa.com/store/?sid=amazon">Amazon</a></li>
                  <li><a class="grey-text text-lighten-3" href="http://www.flippaisa.com/store/?sid=airtel">Airtel</a></li>
                  <li><a class="grey-text text-lighten-3" href="http://www.flippaisa.com/store/?sid=mobikwik">Mobkwiki</a></li>
                </ul>
              </div>
             </div>
            <div class="row">
              <div class="col l8 s12">
                <h5 class="white-text">FlipPaisa</h5>
                <p class="grey-text text-lighten-4"><font size="2">FlipPaisa.com is India's Fastest Growing Cashback and rewards website. Our goal is to help our members save on their regular online purchases, so that they can Get Always Something EXTRA!!!FlipPaisa provides you a Smart way to get Extra Saving on online shopping!!!</font></p>
              </div>
              <div class="col l4 s12">
                <h5 class="white-text">Connect With Us</h5>
              
                <ul>
                  <li><a class="grey-text text-lighten-3" href="https://www.facebook.com/FlipPaisa">
                        <img alt="find us on facebook" src="images/fb2.jpg" class="SocialImgCircle">
                        </a>
                        <a class="grey-text text-lighten-3" href="https://twitter.com/flippaisa">
                        <img alt="follow us on facebook" src="images/twitter2.png" class="SocialImgCircle">
                        </a>
                        <a class="grey-text text-lighten-3" href="https://plus.google.com/+FlippaisaIndia/videos">
                        <img alt="Google Plus" src="images/gplus2.png" class="SocialImgCircle">
                        </a>
                        <a class="grey-text text-lighten-3" href="https://www.youtube.com/user/FlipPaisa">
                        <img alt="Youtube" src="images/youtube2.png" class="SocialImgCircle">
                        </a><a class="grey-text text-lighten-3" href="https://www.linkedin.com/company/flippaisa">
                        <img alt="linkedin" src="images/linkedin2.png" class="SocialImgCircle">
                        </a></li>
                </ul>
              </div>
            </div>
          </div>
          <div class="footer-copyright">
            <div class="container">
All Rights Reserved. © 2014-2016 FlipPaisa Services Pvt. Ltd.
            <a class="grey-text text-lighten-4 right" href="#!">More Links</a>
            </div>
          </div>
        </footer>


   <!-- JQuery Inclusions -->
  <script src="js/jquery.min.js"></script>
  <script src="js/materialize.js"></script>
  <script src="js/init.js"></script>





  </body>




</html>
  