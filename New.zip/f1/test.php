<?php

$m = 1;
$n = 1;
$count1 = 0;
$details1 = "";
$coupon = "";
$expiry = "";
$link = "";

$result = mysql_query("SELECT * FROM deals WHERE storeid = '$store_name'") or die (mysql_error());
	 $count1 = mysql_num_rows($result);
	
	//Condition of offer availability
if($count1 == 0){
echo '<img src="nooffer.png" >';	
} else{
echo '<img src="offor.png" >';	
} 
	 
while ($m <= $count1){
$sql_query = mysql_query("SELECT * FROM deals WHERE id='$n' AND storeid = '$store_name' LIMIT 1") or die (mysql_error());
		
		 if ((mysql_num_rows($sql_query)) == 0){
			 $n++;
		 }else{
		
			while($sql_name = mysql_fetch_array($sql_query)){
			$coupon = $sql_name['coupon'];
			$expiry = $sql_name['expiry'];
			$details1 = $sql_name['details'];
			$link = $sql_name['link'];
			$oid = $sql_name['id'];
			}
// Timer

echo "<script>

    CountDownTimer('"; print ($expiry); echo "', 'countdown"; print($n); echo "');";


echo "    function CountDownTimer(dt, id)
    {
        var end = new Date(dt);

        var _second = 1000;
        var _minute = _second * 60;
        var _hour = _minute * 60;
        var _day = _hour * 24;
        var timer;

        function showRemaining() {
            var now = new Date();
            var distance = end - now;
            if (distance < 0) {

                clearInterval(timer);
                document.getElementById(id).innerHTML = 'EXPIRED!';

                return;
            }
            var days = Math.floor(distance / _day);
            var hours = Math.floor((distance % _day) / _hour);
            var minutes = Math.floor((distance % _hour) / _minute);
            var seconds = Math.floor((distance % _minute) / _second);

			document.getElementById(id).innerHTML = 'Expires in: ';
            document.getElementById(id).innerHTML += days + ' Days ';
            document.getElementById(id).innerHTML += hours + ' Hrs ';
            document.getElementById(id).innerHTML += minutes + ' Mins ';
            document.getElementById(id).innerHTML += seconds + ' Secs';
			
        }

        timer = setInterval(showRemaining, 1000);
    }

</script> ";

//Timer


echo '<div class="first grid8 introduction">';

echo '<br>';

echo '<h9>'; print($details1); echo '</h9>';

echo '<br/>';

//echo '<div class="meta">';

echo '<a href="popup/?oid=';print($oid);echo'&sid=';print($store_name);echo'" class="action-button pink">Get this Deal</a> </div>
  <div id="countdown">	<div id="countdown'; print($n); echo '" style="color:#FF0004"> Getting Expiry Time...</div>';

echo '<div class="clear"></div>';

echo '<br/>';

echo '</div>';


$m++;
$n++;	
}
}
?>